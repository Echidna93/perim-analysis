library('rjson')
library('dplyr')

options(warn=2, error=recover)
path<-"/data/jackx022/perim-data/perim-fence-data/s/S09/A63"
# get our results as a dataframe
res<-fromJSON(file=paste0(path, "/", "A63_megaoutput_vb.json"))

# check if our directories exist
if(!dir.exists(paste0(path, "/","empty")) &
   !dir.exists(paste0(path, "/","positive-images"))){
dir.create(paste0(path, "/", "empty"))
dir.create(paste0(path, "/", "positive-images"))
}

# unsorted DIR
fromDir<-file.path(path)
toDir<-file.path(paste0(path, "/", "positive-images"))
toDire<-file.path(paste0(path, "/", "empty"))
res[2]$detection_categories
# grab the index of our animal detection category
animal_index <- NULL
# need some exception for this
for(i in 1:length(res[2]$detection_categories)){
  if(res[2]$detection_categories[[i]] == "animal"){
    animal_index = i
  }
}

# now we need to parse thru the indices of the data portion
# positive files
posFiles <- list()
emptyFiles <- list()
j <- 1
k <- 1
for(i in 1:length(res[1]$images)){
  if(length(res[1]$images[[i]]$detections) != 0){
    posFiles[j] <- res[1]$images[[i]]$file[[1]] # grab the file name and append it to the lists
    j = j + 1
    }
  else{
	  emptyFiles[k] <- res[1]$images[[i]]$file[[1]] # grab the file name and append it to the lists
   	  k = k + 1
  }

}

# now we can just run thru and have this copy our files to a new
# directory
unsrtd.files<-list.files(fromDir)
for(i in 1:length(unsrtd.files)){
  for(j in 1:length(posFiles)){
    if(unsrtd.files[i] == posFiles[[j]]){
      file.copy(paste0(fromDir, "/", unsrtd.files[i]),
                paste0(toDir, "/", posFiles[[j]])
      )
      }
    }
}

# do the same to our empty files to clean it up
unsrtd.files<-list.files(fromDir)
for(i in 1:length(unsrtd.files)){
  for(j in 1:length(emptyFiles)){
    if(unsrtd.files[i] == emptyFiles[[j]]){
      file.copy(paste0(fromDir,"/", unsrtd.files[i]),
                paste0(toDire, "/", emptyFiles[[j]])
      )
      }
    }
}

