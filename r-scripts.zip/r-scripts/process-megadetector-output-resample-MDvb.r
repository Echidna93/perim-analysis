library('rjson')
library('dplyr')

options(warn=2, error=recover)
#path<-"/data/jackx022/perim-data/perim-fence-data/s/S09/A65"
path<-"/home/jackx022/Desktop/test"
# get our results as a dataframe
res<-fromJSON(file=paste0(path, "/", "A23_megaoutput_vb.json"))
# unsorted DIR
#fromDir<-file.path(path)
toDir<-file.path(paste0(path, "/", "positive-images"))
fromDir<-file.path(paste0(path, "/", "empty"))
# grab the index of our animal detection category
animal_index <- NULL
# need some exception for this
for(i in 1:length(res[2]$detection_categories)){
  if(res[2]$detection_categories[[i]] == "animal"){
    animal_index = i
  }
}

# now we need to parse thru the indices of the data portion
# positive files
posFiles <- list()
unsrtd.files<-list.files(fromDir)
j <- 1
for(i in 1:length(res[1]$images)){
  if(length(res[1]$images[[i]]$detections) != 0){
    posFiles[j] <- res[1]$images[[i]]$file[[1]] # grab the file name and append it to the lists
    j = j + 1
    }
}

# now we can just run thru and have this copy our files to a new
# directory
if((length(posFiles)!=0)){
   for(j in 1:length(posFiles)){ 
      file.copy(paste0(fromDir, "/", posFiles[[j]]),
                paste0(toDir, "/", posFiles[[j]]))
      file.remove(paste0(fromDir,"/", posFiles[[j]])) # now we can delete so we're not leaving behind a ton of copies  
    	}
    }	
