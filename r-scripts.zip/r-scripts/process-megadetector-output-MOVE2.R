library('rjson')
library('dplyr')

options(warn=2, error=recover)
site <- "S09"
cam <- "A18"
num.samps <- 10
path<-paste0("/data/jackx022/perim-data/perim-fence-data/s", "/", site, "/", cam)

# path<-"/home/jackx022/Desktop/test"


# get our results as a dataframe
res<-fromJSON(file=paste0(path, "/", cam, "_megaoutput_vb.json"))

# check if our directories exist
if(!dir.exists(paste0(path, "/","empty")) &
   !dir.exists(paste0(path, "/","positive-images"))){
dir.create(paste0(path, "/", "empty"))
dir.create(paste0(path, "/", "positive-images"))
}

# unsorted DIR
fromDir<-file.path(path)
toDir<-file.path(paste0(path, "/", "positive-images"))
toDire<-file.path(paste0(path, "/", "empty"))
# grab the index of our animal detection category
animal_index <- NULL
# need some exception for this
for(i in 1:length(res[2]$detection_categories)){
  if(res[2]$detection_categories[[i]] == "animal"){
    animal_index = i
  }
}

# now we need to parse thru the indices of the data portion
# positive files
posFiles <- list()
emptyFiles <- list()
j <- 1
k <- 1
for(i in 1:length(res[1]$images)){
  if(length(res[1]$images[[i]]$detections) != 0){
    posFiles[j] <- res[1]$images[[i]]$file[[1]] # grab the file name and append it to the lists
    j = j + 1
    }
  else{
	  emptyFiles[k] <- res[1]$images[[i]]$file[[1]] # grab the file name and append it to the lists
   	  k = k + 1
  }

}

# now we can just run thru and have this copy our files to a new
# directory
unsrtd.files<-list.files(fromDir)
if((length(posFiles)!=0)){
for(i in 1:length(unsrtd.files)){
  for(j in 1:length(posFiles)){
    if(unsrtd.files[i] == posFiles[[j]]){
      file.copy(paste0(fromDir, "/", unsrtd.files[i]),
                paste0(toDir, "/", posFiles[[j]])
      )
      file.remove(paste0(fromDir,"/", unsrtd.files[i])) # now we can delete so we're not leaving behind a ton of copies
  
    }
    }	
	}
}

# do the same to our empty files to clean it up
if((length(emptyFiles)!=0)){
for(i in 1:length(unsrtd.files)){
  for(j in 1:length(emptyFiles)){
    if(unsrtd.files[i] == emptyFiles[[j]]){
      file.copy(paste0(fromDir,"/", unsrtd.files[i]),
                paste0(toDire, "/", emptyFiles[[j]]))
      file.remove(paste0(fromDir,"/", unsrtd.files[i])) # now we can delete so we're not leaving behind a ton of copies
      }
    }
}
}
# these are what you need to change when it runs
path = paste0("/data/jackx022/perim-data/perim-fence-data/s/", site, "/", cam, "/empty")
output.path <- "/home/jackx022/Desktop/sample-images"
# number of negative images we want to sample

pathsplit<-strsplit(path, "/")

files<-setdiff(list.files(path), list.dirs(recursive=FALSE, full.names="FALSE"))
samp.files.indx<-sample(c(1:length(files)), num.samps, replace=FALSE)
samp.files<-files[samp.files.indx] 
filename<-paste0(pathsplit[[1]][length(pathsplit[[1]])], "-", pathsplit[[1]][length(pathsplit[[1]])-1], ".txt")

# check if our directory exists
site.dir <- pathsplit[[1]][length(pathsplit[[1]])-2]
if(!dir.exists(paste0(output.path, "/", site.dir))){
dir.create(paste0(output.path, "/", site.dir))
}
file.create(paste0(output.path, "/",site.dir,"/",filename))
sink(paste0(output.path, "/", site.dir ,"/", filename))
for(i in 1:length(samp.files)){
  cat(samp.files[i])
  cat("\n")
}
sink()


path.p = paste0("/data/jackx022/perim-data/perim-fence-data/s/", site, "/", cam, "/", "positive-images")
output.path <- "/home/jackx022/Desktop/positive-images"
# grab the positive images and throw them into a file
pathsplit<-strsplit(path.p, "/")
files<-setdiff(list.files(path.p), list.dirs(recursive=FALSE, full.names="FALSE"))
filename<-paste0(pathsplit[[1]][length(pathsplit[[1]])], "-", pathsplit[[1]][length(pathsplit[[1]])-1], ".txt")

# check if our directory exists
site.dir <- pathsplit[[1]][length(pathsplit[[1]])-2]
if(!dir.exists(paste0(output.path, "/", site.dir))){
  dir.create(paste0(output.path, "/", site.dir))
}

file.create(paste0(output.path, "/",site.dir,"/",filename))
sink(paste0(output.path, "/", site.dir ,"/", filename))
for(i in 1:length(files)){
  cat(files[i])
  cat("\n")
}
sink()



