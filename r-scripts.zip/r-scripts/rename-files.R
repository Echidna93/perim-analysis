# rename files
# 

# path = "E:\\w\\S01\\A07"

# point this to a camera
path = "/data/jackx022/perim-data/perim-fence-data/s/S09/A80"
options(warn=1)
pathsplit<-strsplit(path, "/")

k = 1
dirs<-list.dirs(path)[-1]
for(i in 1:length(dirs)){
  dir.pth <- strsplit(dirs[i], "/") 
  dir <- dir.pth[[1]][length(dir.pth[[1]])]
  files<-list.files(paste0(path, "/", dir))
  for(j in 1:length(files)){
    file.rename(paste0(path, "/", dir, "/", files[j]),
              paste0(path,"/",
                     paste0(pathsplit[[1]][(length(pathsplit[[1]])-2)],"-",
                            pathsplit[[1]][(length(pathsplit[[1]])-1)],"-",
                            pathsplit[[1]][length(pathsplit[[1]])],"-",
                            k,".JPG")))
    k = k + 1
  }
}
# for testing out new data 
# path = "C:\\Users\\jackx\\Desktop\\image-recog\\images\\new\\new"
# files<-list.files(path)
# for(i in 1:length(files)){
#   file.rename(paste0(path, "\\", files[i]), paste0(path, "\\", i,".JPG"))
# }
