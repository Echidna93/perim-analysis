# these are what you need to change when it runs


# path should point to the directory where the images are
# i.e. /data/jackx022/perim-data/perimeter-fence-data/s/S01/A11
site <- "S09"
cam <- "A84"

path = paste0("/data/jackx022/perim-data/perim-fence-data/s/", site, "/", cam, "/empty")
output.path <- "/home/jackx022/Desktop/sample-images"
# number of negative images we want to sample
num.samps <- 15

pathsplit<-strsplit(path, "/")

files<-setdiff(list.files(path), list.dirs(recursive=FALSE, full.names="FALSE"))
samp.files.indx<-sample(c(1:length(files)), num.samps, replace=FALSE)
samp.files<-files[samp.files.indx] 
filename<-paste0(pathsplit[[1]][length(pathsplit[[1]])], "-", pathsplit[[1]][length(pathsplit[[1]])-1], ".txt")

# check if our directory exists
site.dir <- pathsplit[[1]][length(pathsplit[[1]])-2]
if(!dir.exists(paste0(output.path, "/", site.dir))){
dir.create(paste0(output.path, "/", site.dir))
}
file.create(paste0(output.path, "/",site.dir,"/",filename))
sink(paste0(output.path, "/", site.dir ,"/", filename))
for(i in 1:length(samp.files)){
  cat(samp.files[i])
  cat("\n")
}
sink()


path.p = paste0("/data/jackx022/perim-data/perim-fence-data/s/", site, "/", cam, "/", "positive-images")
output.path <- "/home/jackx022/Desktop/positive-images"
# grab the positive images and throw them into a file
pathsplit<-strsplit(path.p, "/")
files<-setdiff(list.files(path.p), list.dirs(recursive=FALSE, full.names="FALSE"))
filename<-paste0(pathsplit[[1]][length(pathsplit[[1]])], "-", pathsplit[[1]][length(pathsplit[[1]])-1], ".txt")

# check if our directory exists
site.dir <- pathsplit[[1]][length(pathsplit[[1]])-2]
if(!dir.exists(paste0(output.path, "/", site.dir))){
  dir.create(paste0(output.path, "/", site.dir))
}

file.create(paste0(output.path, "/",site.dir,"/",filename))
sink(paste0(output.path, "/", site.dir ,"/", filename))
for(i in 1:length(files)){
  cat(files[i])
  cat("\n")
}
sink()



