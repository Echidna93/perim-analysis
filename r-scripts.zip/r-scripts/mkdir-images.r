# these are what you need to change when it runs


# path should point to the directory where the images are
# i.e. /data/jackx022/perim-data/perimeter-fence-data/s/S01/A11
frompath = "/data/jackx022/perim-data/perim-fence-data/s/S04/A09c/empty"
output.path <- "/home/jackx022/Desktop/sample-images"
# number of negative images we want to sample
num.samps <- 200
toDir<-file.path(paste0(path, "/", "positive-images"))
pathsplit<-strsplit(path, "/")

files<-setdiff(list.files(path), list.dirs(recursive=FALSE, full.names="FALSE"))
samp.files.indx<-sample(c(1:length(files)), num.samps, replace=FALSE)
samp.files<-files[samp.files.indx] 
filename<-paste0(pathsplit[[1]][length(pathsplit[[1]])], "-", pathsplit[[1]][length(pathsplit[[1]])-1], ".txt")

# check if our directory exists
site.dir <- pathsplit[[1]][length(pathsplit[[1]])-2]
if(!dir.exists(paste0(output.path, "/", site.dir))){
dir.create(paste0(output.path, "/", site.dir))
}


# file.create(paste0(output.path, "/",site.dir,"/",filename))
# sink(paste0(output.path, "/", site.dir ,"/", filename))
for(i in 1:length(samp.files)){
 unsrtd.files<-list.files(fromDir)
for(i in 1:length(unsrtd.files)){
  for(j in 1:length(emptyFiles)){
    if(unsrtd.files[i] == emptyFiles[[j]]){
      file.copy(paste0(fromDir,"/", unsrtd.files[i]),
                paste0(toDire, "/", emptyFiles[[j]])
      )
      }
    }
}


      	file 
}
# sink()
