library("rgdal")
library("raster")
library("sf")
library("leafsync")
library("dplyr")
library("ggplot2")
library("stars")
library(spatialEco)
library(spatstat.random)

nsamp=20 # number of samples we want
point.dist.cond = 20 # want meters between points
utm <- st_crs("+proj=utm +zone=15 +datum=WGS84 +units=m +no_defs")
# our paths 
# CHANGE THESE TO WHEREVER YOU PUT YOUR SHPS
shp_path <- "C:/Users/jackx/Desktop/mark-volk/mark-volk.shp"
rast_path <- "C:/Users/jackx/Desktop/clipped-area/clipped-area.tif"

# grabs the name of the farm or farmer
shp_name<-unlist(strsplit(shp_path, "[.]"))
shp_name<-strsplit(shp_name[1], "/")
farm_name<-shp_name[[1]][length(shp_name[[1]])] # get the name of the farmer

# euclidean distance function
# use this for spacing out our points
eucDistance<-function(P1, P2){
  sqrt((((P2[1]-P1[1])^2)+((P2[2]-P1[2])^2)))
}
# read in raster
landcover<-raster(rast_path)
#  read in shp file
farm.full<-st_read(shp_path)
# grab the extent of our farm
farm.extent<-extent(farm.full)
# buffer the extent so that we don't cut off the farm
farm.extent<-extend(farm.extent, 100)
# crop our lc dataset to the buffered extent
lc.cropped<-crop(landcover, farm.extent) %>% 
  st_as_stars() %>%
  st_as_sf()

# buffer the full farm shp
farm.full
farm.buff<-farm.full %>%
  st_buffer(30) # buffer by 30m

# subtract the buffered farm from the original shp
farm.fenceline.buff<-st_difference(farm.buff, farm.full)

# intersect our fencline and our cropped landcover tif
lc.fenceline<-st_intersection(lc.cropped, farm.fenceline.buff)

# convert back to raster so we can use sampleStratified
lc.fenceline.rast<-st_rasterize(lc.fenceline)
lc.fenceline.rast<-as(lc.fenceline.rast, "Raster")

# sample fenceline raster
sample.points <- sampleStratified(x=lc.fenceline.rast$clipped.area,
                                  size=8,
                                  na.rm=TRUE,
                                  xy=TRUE,
                                  sp=TRUE)

# we'll use this for any point that doesn't fit our distance criterion
bad.indx.lst <- c()

k<-1
data.points<-list()

for(i in 1:(nrow(sample.points)-1)){
  p1 <- c(sample.points$x[i], sample.points$y[i])
  for(j in (i+1):nrow(sample.points)){
    p2 <- c(sample.points$x[j], sample.points$y[j])
    # last condition will ensure that only points with indices not already in 
    # will go thru this condition; 
    # gets around landcover classes with smaller
    # representations
    if((i != j) & (eucDistance(p1, p2) < point.dist.cond) & 
      ((! i %in% bad.indx.lst) | (! j %in% bad.indx.lst))){
      bad.indx.lst[k]<-i
      k<-k+1
    }
  }
}
bad.indx.lst<-unique(bad.indx.lst)
sample.points<-sample.points[-c(bad.indx.lst),]

# check for filtering
(nrow(sample.points))

# filter off excess points
sample.points<-sample.points[-c(nsamp+1:nrow(sample.points)),]

# convert points to gpx points
# first convert from UTM NAD83 espg:26915 -> long lat
long.lat <- spTransform(sample.points, CRS("+proj=longlat"))


# can plot to check our point distribution
plot(lc.fenceline.rast$clipped.area)
points(sample.points, col="black", pch=19)

# write our waypoints
# this will by default save to the root directory of our project
# with the name of the farm that we save our shapefile as
writeOGR(long.lat, dsn=paste0(".","/",farm_name,".gpx", sep=""),
         dataset_options="GPX_USE_EXTENSIONS=yes",layer="waypoints",driver="GPX", overwrite_layer = T)
